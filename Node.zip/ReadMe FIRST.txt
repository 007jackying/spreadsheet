1. extract this zip file to an empty folder
2. launch terminal/cmd and navigate to this folder
3. type this following command:
	npm install
4. then type in this command:
	node app.js
5. open your broswer and go to http:/localhost:8000


USER ACCOUNT FOR TESTING:
EMAIL: utsav@mun.ca
PASSWORD: cccccdd


ADMIN ACCOUNTS FOR TESTING:
EMAIL: thlee@mun.ca
PASSWORD: tyui